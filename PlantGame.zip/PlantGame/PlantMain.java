package com.PlantGame;
import com.Plant.Anggrek;
import com.Plant.Mawar;
import com.Plant.Melati;

import java.util.Scanner;
public class PlantMain
{
    public static void main(String[] args) {
        com.Plant.Anggrek anggrek = new Anggrek();
        com.Plant.Mawar mawar = new Mawar();
        Melati melati = new Melati();
        Scanner sc = new Scanner(System.in);
        int selectPlan;
        int inp = 0;
        boolean runApp = true;
        do {
            System.out.println("Pilih Jenis Tanaman: ");
            System.out.println("1. Anggrek");
            System.out.println("2. Mawar");
            System.out.println("3. Melati");
            System.out.println("4. Exit");
            System.out.println("Masukan angka: ");
            selectPlan = sc.nextInt();

            switch (selectPlan) {
                case 1 -> {
                    do {
                        System.out.println("=========== "+ anggrek.getJenis() +" ===========");
                        System.out.println("Masukkan: 0 untuk memberi air, 1 untuk memberi pupuk, 999 untuk keluar");
                        inp = sc.nextInt();
                        switch (inp) {
                            case 0 -> anggrek.beriAir();
                            case 1 -> anggrek.beriPupuk();
                        }
                        anggrek.displayPlant();
                    } while (inp != 999);
                }
                case 2 -> {
                    do {
                        System.out.println("=========== "+ mawar.getJenis() +" ===========");
                        System.out.println("Masukkan: 0 untuk memberi air, 1 untuk memberi pupuk, 999 untuk keluar");
                        inp = sc.nextInt();
                        switch (inp) {
                            case 0 -> mawar.beriAir();
                            case 1 -> mawar.beriPupuk();
                        }
                        mawar.displayPlant();
                    } while (inp != 999);
                }
                case 3 -> {
                    System.out.println("=========== "+ melati.getJenis() +" ===========");
                    System.out.println("Masukkan: 0 untuk memberi air, 1 untuk memberi pupuk, 999 untuk keluar");
                    inp = sc.nextInt();
                    switch (inp) {
                        case 0 -> melati.beriAir();
                        case 1 -> melati.beriPupuk();
                    }
                    anggrek.displayPlant();
                }
                case 4 -> {
                    runApp = false;
                }
            }
        } while (runApp);
    }
}
