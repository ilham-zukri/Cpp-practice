package com.PlantGame;

public class Mawar extends Plant {
    private final String jenis;

    public Mawar(){
        super();
        jenis = "Mawar";
    }

    @Override
    public void cekKondisiTumbuh() {
        if(getJumlahAir() >=2 && getJumlahPupuk() >=2) {
            tumbuh();
        }
    }

    @Override
    public void tumbuh() {
        if(getStatusTumbuh() <4) {
            setJumlahAir(getJumlahAir() - 2);
            setJumlahPupuk(getJumlahPupuk() - 2);
            setStatusTumbuh(getStatusTumbuh() + 1);
        }
    }

    public String getJenis() {
        return jenis;
    }
}
